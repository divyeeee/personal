import cv2             # Library for computer vision, OpenCV
import mediapipe as mp # ML pipeline for gesture recognition. 
import socket          # Library for creating sockets, required for transmission of data between servers

                       # Establish TCP connection to the ESP
esp_ip = '192.168.137.140' # IP of our ESP assigned by the host(Laptop)
esp_port = 80              # default port for HTTP traffic

mp_hands = mp.solutions.hands 
mp_drawing = mp.solutions.drawing_utils

width = 1280
height = 720

cam = cv2.VideoCapture(0, cv2.CAP_DSHOW) # Initializes video capture from a camera, here 0 means default camera on our laptops,v2.CAP_DSHOW is used to solve compatibility issues and to improve performance on Windows systems.
cam.set(cv2.CAP_PROP_FRAME_WIDTH, width)   
cam.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
# Sets the display window resolution at 1280x720 pixels.
cam.set(cv2.CAP_PROP_FPS, 30)           # Set the frame rate of the video capture device (e.g., a webcam) to 30 frames per second (FPS). 
cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
last_message = b"none"                  # Stores the last message sent to the ESP

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    # socket.AF_INET: Specifies the address family as IPv4. This means the socket will use standard IP addresses.
    # socket.SOCK_STREAM: Specifies that the socket will use TCP (a reliable, connection-oriented protocol) rather than UDP.
    s.connect((esp_ip, esp_port))      # This line attempts to establish a TCP connection to the specified address
    
    last_message = b"none"             # Stores the last message sent to the ESP

    with mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.5) as hands:
        # min_detection_confidence and min_tracking_confidence values tell the model to predict joints and track the hand upto the decided level of accuracy
        while cam.isOpened():         # This line speciifes to proceed only if the video is being captured.
            ret, frame = cam.read()
            if not ret:
                break

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(frame_rgb)
            finger_count = 0
            # Above lines capture the video frame by frame and apply changes like converting from BGR to RGB format, and then the hand gestures on the screen are identified and stored
            if results.multi_hand_landmarks:                        # Detects if there is a hand in the frame
                for hand_landmarks in results.multi_hand_landmarks: # Looping through each detected hand
                    mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS) # Draws the detected hand landmarks and their connections on the video frame.

                    finger_tips = [mp_hands.HandLandmark.INDEX_FINGER_TIP,
                                   mp_hands.HandLandmark.MIDDLE_FINGER_TIP,
                                   mp_hands.HandLandmark.RING_FINGER_TIP,
                                   mp_hands.HandLandmark.PINKY_TIP]
                    # Above code snipet stores a list of landmarks/points corresponding to the tips of the index, middle, ring, and pinky fingers.
                    # Count fingers
                    for tip in finger_tips:
                        if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[tip - 2].y:
                            finger_count += 1
                    # Above code snipet counts the number of extended fingers by checking if the point on the tip is above or below the point on the second joint of the finger from the tip.
                    # Finger is said to be extended if the tip is above the second joint from the tip and vice-versa.
                    # Thumb detection based on handedness
                    handedness = results.multi_handedness[0].classification[0].label
                    thumb_tip = mp_hands.HandLandmark.THUMB_TIP
                    thumb_ip = mp_hands.HandLandmark.THUMB_IP

                    if (handedness == 'Left' and hand_landmarks.landmark[thumb_tip].x > hand_landmarks.landmark[thumb_ip].x) or \
                       (handedness == 'Right' and hand_landmarks.landmark[thumb_tip].x < hand_landmarks.landmark[thumb_ip].x):
                        finger_count += 1
                    # Above code snipet accounts for thumbs when processing hand and upadting the finger count to include the thumb.
                    # For left hand: The thumb is said to be extended if the the thumb tip’s x-coordinate is greater than the IP (interphalangeal) joint.
                    # For right hand: The thumb is said to be extended if the the thumb tip’s x-coordinate is less than the IP (interphalangeal) joint.
                    # Display finger count
                    if 0 < finger_count <= 4:
                        cv2.putText(frame, f"{finger_count}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                        # Determine the message to send based on the number of fingers
                        message = b"none"
                        match finger_count:
                            case 1:
                                message = b"one"
                                if message != last_message:
                                    s.sendall(message+b"\r")
                                    last_message = message
                            case 2:
                                message = b"two"
                                if message != last_message:
                                    s.sendall(message+b"\r")
                                    last_message = message
                            case 3:
                                message = b"three"
                                if message != last_message:
                                    s.sendall(message+b"\r")
                                    last_message = message
                            case 4:
                                message = b"four"
                                if message != last_message:
                                    s.sendall(message+b"\r")
                                    last_message = message
                    # If the finger count is in range [1,4] and not same as the previous command, then the corresponding message is sent to the ESP using sendall() function                
                    else:
                        cv2.putText(frame, "Invalid Gesture", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA) #If the finger count is not in desired range, then "Invalid gesture is shown on the display window."
                        message = b"zero"
                        # Send message if changed
                        if message != last_message:
                            s.sendall(message)
                            last_message = message

                    
            
            cv2.imshow('Finger Count', frame)     # Shows modified output video with detected landmarks, connections and text.
            if cv2.waitKey(1) & 0xFF == ord('q'): # This function waits for a key event for a specified number of milliseconds. In this case, 1 millisecond. Here the key event is pressing of the key 'q' which break out of loop to shut down the video capture and display window.
                break
            
cam.release()           #Shuts down the video capture, laptop camera stops recording.
cv2.destroyAllWindows() #Shuts down the display window where the window is being displayed.
